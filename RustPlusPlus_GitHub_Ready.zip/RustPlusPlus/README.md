# Rust++

A **non-generative, rule-based** coding assistant written in Rust. It uses no AI model,
no AI API, and makes no external AI inference calls. Answers and code transformations
come from bundled templates and explicit rules.

## What this first version includes

- A reusable Rust core for matching requests against built-in patterns.
- Built-in starter templates for C++, Rust, Python, JavaScript, Java, C#, and Lua.
- A safe, explicit transformation: add a language-appropriate comment header.
- Explanations attached to every generated template and transformation.
- A command-line interface for testing without Discord.
- An optional Discord gateway adapter using `!rpp` commands.

## Important scope and safety notes

This is an honest starter implementation, not a full autonomous programmer.
It does not invent arbitrary code. Unsupported requests receive a clear "not in the
built-in library" response. The first transformation is intentionally conservative.
It does not yet parse every language grammar or perform arbitrary syntax-tree edits.
The validator performs lightweight structural checks; it does **not** replace the
real compiler for each language.

Compilation is deliberately not run on untrusted Discord code in this starter.
When real compilation is added, run compilers inside isolated containers or sandboxes
with CPU, memory, time, filesystem, and network restrictions.

## Requirements

- Rust stable toolchain (install from https://rustup.rs)
- Optional: a Discord bot token for Discord mode

## Run locally

```bash
cargo run -- --help
cargo run -- template cpp
cargo run -- template rust
cargo run -- explain cpp
cargo run -- analyze cpp "why does my program have an undefined reference"
cargo run -- transform python sample.py add-header
cargo test
```

The CLI uses only bundled data and local code.

## Discord setup

1. Create an application and bot in the Discord Developer Portal.
2. Enable **Message Content Intent** for this starter's `!rpp` interface.
3. Invite the bot with View Channels, Send Messages, and Read Message History.
4. Copy `.env.example` to `.env` and set `DISCORD_TOKEN`.
5. Run:

```bash
cargo run -- --discord
```

Discord connectivity requires internet access. The assistant's matching, templates,
transformations, and explanations run locally on the bot host. No AI API is used.

### Discord commands

- `!rpp help`
- `!rpp template cpp`
- `!rpp template rust`
- `!rpp explain python`
- `!rpp analyze cpp <question>`

For long code, attach a file or use the local CLI. The first Discord version does not
yet download attachments or save multi-file projects.

## Supported languages

`cpp`, `rust`, `python`, `javascript`, `java`, `csharp`, `lua`

## Architecture

```text
src/
  main.rs          CLI entry point
  lib.rs           shared assistant core
  language.rs      language definitions
  knowledge.rs     predefined explanations and templates
  engine.rs        deterministic request matching
  transform.rs     conservative source transformation
  validate.rs      lightweight checks (not a compiler)
  discord.rs       optional Discord adapter
```

## Roadmap

1. Add tree-sitter parsers per language and syntax-tree-aware edits.
2. Add before/after diffs, approval, undo, and project/file storage.
3. Add real local compiler adapters (Clang, rustc, Python, Node, Java, .NET, Lua).
4. Run compilation and execution only in hardened sandboxes.
5. Add Discord slash commands and an embedded Discord Activity workspace.
