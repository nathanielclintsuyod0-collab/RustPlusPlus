import { invoke } from "@tauri-apps/api/core";
import "./style.css";

const $ = (s) => document.querySelector(s);
const languages = ["cpp", "rust", "python", "javascript", "java", "csharp", "lua"];
let currentPath = "";
let isTauri = !!(window.__TAURI_INTERNALS__);

$("#app").innerHTML = `
<div class="shell">
  <aside class="sidebar"><div class="brand"><div class="brand-mark">R<span>++</span></div><div><b>Rust++</b><small>OFFLINE CODE ASSISTANT</small></div></div>
    <div class="side-label">WORKSPACE</div><button class="nav active" data-tab="editor">▣ <span>Code editor</span></button><button class="nav" data-tab="assistant">✦ <span>Assistant</span></button><button class="nav" data-tab="about">ⓘ <span>About Rust++</span></button>
    <div class="sidebar-bottom"><span class="status-dot"></span><span>Deterministic engine</span><small>No AI APIs</small></div>
  </aside>
  <main class="main"><header class="topbar"><button id="menu" class="icon-btn" aria-label="Menu">☰</button><div><b id="page-title">Code editor</b><small id="platform-label">Local workspace</small></div><div class="top-spacer"></div><span class="offline-pill"><i></i> OFFLINE ENGINE</span></header>
  <section id="editor-view" class="view">
    <div class="welcome"><div><p class="eyebrow">YOUR CODING WORKSPACE</p><h1>Build something<br/><em>brilliant.</em></h1><p class="muted">Create, inspect and improve code with deterministic tools — no generative AI.</p></div><div class="hero-orbit"><div>R<span>++</span></div></div></div>
    <div class="toolbar"><label>LANGUAGE<select id="language">${languages.map(x=>`<option value="${x}">${({cpp:"C++",rust:"Rust",python:"Python",javascript:"JavaScript",java:"Java",csharp:"C#",lua:"Lua"})[x]}</option>`).join("")}</select></label><div class="tool-actions"><button id="template" class="btn primary">＋ Template</button><button id="explain" class="btn">Explain</button><button id="check" class="btn">Check code</button></div></div>
    <div class="workspace"><div class="editor-card"><div class="card-head"><span><i class="file-dot"></i><span id="filename">untitled.py</span></span><div><button id="open" class="tiny">Open</button><button id="save" class="tiny">Save</button></div></div><textarea id="source" spellcheck="false" autocapitalize="off" autocomplete="off" placeholder="// Start writing your code here..." aria-label="Source code"></textarea><div class="editor-foot"><span id="line-count">1 line</span><span>LOCAL FILE</span></div></div><div class="result-card"><div class="card-head"><b>Rust++ results</b><span class="result-tag">BUILT-IN RULES</span></div><div id="result" class="result-body"><div class="empty-state"><div class="empty-icon">✦</div><b>Ready when you are</b><p>Generate a starter, explain a language, or check your source code.</p></div></div></div></div>
  </section>
  <section id="assistant-view" class="view hidden"><div class="section-intro"><p class="eyebrow">RULE-BASED ASSISTANT</p><h1>Ask Rust++.</h1><p class="muted">Ask about bundled programming concepts and known errors. Answers come from local rules and curated notes.</p></div><div class="ask-card"><textarea id="question" rows="4" placeholder="Example: What does undefined reference mean?"></textarea><button id="ask" class="btn primary">Analyze request →</button></div><div id="assistant-result" class="result-card assistant-output"><div class="empty-state"><div class="empty-icon">✦</div><b>No analysis yet</b><p>Your results will appear here.</p></div></div></section>
  <section id="about-view" class="view hidden"><div class="section-intro"><p class="eyebrow">ABOUT THE PROJECT</p><h1>Built on rules.<br/><em>Powered by Rust.</em></h1><p class="muted">Rust++ is a deterministic coding assistant. It does not call AI services or run a generative model.</p></div><div class="about-grid"><div class="about-tile"><b>7</b><span>Supported languages</span></div><div class="about-tile"><b>0</b><span>AI APIs and models</span></div><div class="about-tile"><b>Local</b><span>Core processing</span></div></div><p class="muted note">Validation is lightweight structural checking, not a substitute for each language's compiler or interpreter.</p></section>
  <footer><span>Rust++ <span class="muted">· Cross-platform foundation</span></span><span id="runtime">Web preview</span></footer>
</main></div>`;

function showResult(target, reply) {
  const el = $(target);
  const code = reply.code ? `<pre><code>${escapeHtml(reply.code)}</code></pre>` : "";
  const list = (reply.explanation || []).map(x=>`<li>${escapeHtml(x)}</li>`).join("");
  el.innerHTML = `<div class="reply"><div class="reply-kicker">${escapeHtml(reply.source || "RUST++")}</div><h2>${escapeHtml(reply.title)}</h2><p>${escapeHtml(reply.message)}</p>${code}${list?`<h3>What this means</h3><ul>${list}</ul>`:""}</div>`;
}
function escapeHtml(s="") { return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function updateLines(){const n=$("#source").value.split("\n").length;$("#line-count").textContent=`${n} ${n===1?"line":"lines"}`;}
function extension(){return ({cpp:"cpp",rust:"rs",python:"py",javascript:"js",java:"java",csharp:"cs",lua:"lua"})[$("#language").value];}
async function run(command,args,target){try{const result=await invoke(command,args);showResult(target,result);}catch(e){$(target).innerHTML=`<div class="error">${escapeHtml(String(e))}</div>`;}}

$("#source").addEventListener("input",updateLines);
$("#language").addEventListener("change",()=>{$("#filename").textContent=`untitled.${extension()}`;});
$("#template").onclick=async()=>{const lang=$("#language").value;try{const r=await invoke("generate_template",{language:lang});if(r.code)$("#source").value=r.code;updateLines();showResult("#result",r);}catch(e){showResult("#result",{title:"Template unavailable",message:String(e),source:"Rust++"});}};
$("#explain").onclick=()=>run("explain_language",{language:$("#language").value},"#result");
$("#check").onclick=()=>run("validate_source",{language:$("#language").value,source:$("#source").value},"#result");
$("#ask").onclick=()=>run("analyze_request",{question:$("#question").value},"#assistant-result");
$("#source").addEventListener("keydown",e=>{if(e.key==="Tab"){e.preventDefault();const a=e.target.selectionStart,b=e.target.selectionEnd;e.target.setRangeText("    ",a,b,"end");updateLines();}});
$("#save").onclick=async()=>{if(!isTauri){alert("Save is available in the installed Rust++ app. The browser preview cannot access local files.");return;}const path=currentPath||prompt("Save file as (full path):",`untitled.${extension()}`);if(!path)return;try{const msg=await invoke("save_source_file",{path,source:$("#source").value});currentPath=path;$("#filename").textContent=path.split(/[\\/]/).pop();$("#result").innerHTML=`<div class="success">${escapeHtml(msg)}</div>`;}catch(e){alert(String(e));}};
$("#open").onclick=async()=>{if(!isTauri){alert("Open is available in the installed Rust++ app. The browser preview cannot access local files.");return;}const path=prompt("Enter the full path of the source file to open:");if(!path)return;try{$("#source").value=await invoke("read_source_file",{path});currentPath=path;$("#filename").textContent=path.split(/[\\/]/).pop();updateLines();}catch(e){alert(String(e));}};
function switchTab(tab){document.querySelectorAll(".view").forEach(x=>x.classList.add("hidden"));$(`#${tab}-view`).classList.remove("hidden");document.querySelectorAll(".nav").forEach(x=>x.classList.toggle("active",x.dataset.tab===tab));$("#page-title").textContent=({editor:"Code editor",assistant:"Assistant",about:"About Rust++"})[tab];}
document.querySelectorAll(".nav").forEach(b=>b.onclick=()=>switchTab(b.dataset.tab));$("#menu").onclick=()=>document.querySelector(".sidebar").classList.toggle("open");
if(isTauri){$("#runtime").textContent="Tauri native app";$("#platform-label").textContent="Desktop / mobile workspace";invoke("app_info").then(info=>console.info("Rust++",info));}
updateLines();
