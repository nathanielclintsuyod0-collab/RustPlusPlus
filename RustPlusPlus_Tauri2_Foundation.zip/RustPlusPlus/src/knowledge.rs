use crate::{language::Language, AssistantReply};

pub fn template(lang: Language) -> AssistantReply {
    let (name, code, explanation) = match lang {
        Language::Cpp => ("C++ starter", r#"#include <iostream>

int main() {
    std::cout << "Hello, world!\n";
    return 0;
}"#, vec![
            "`#include <iostream>` makes standard input/output facilities available.".into(),
            "`main` is the program entry point.".into(),
            "`std::cout` writes text to standard output.".into(),
            "`return 0` signals successful completion.".into(),
        ]),
        Language::Rust => ("Rust starter", r#"fn main() {
    println!("Hello, world!");
}"#, vec![
            "`fn main()` defines the executable entry point.".into(),
            "`println!` is a standard-library macro that prints a line.".into(),
        ]),
        Language::Python => ("Python starter", r#"def main():
    print("Hello, world!")

if __name__ == "__main__":
    main()"#, vec![
            "`def main()` groups the program's starting logic in a function.".into(),
            "`print` writes text to the console.".into(),
            "The `__name__` guard runs `main` when this file is executed directly.".into(),
        ]),
        Language::JavaScript => ("JavaScript starter", r#"function main() {
  console.log("Hello, world!");
}

main();"#, vec![
            "`function main()` declares a function.".into(),
            "`console.log` writes a message to the console.".into(),
            "`main()` invokes the function.".into(),
        ]),
        Language::Java => ("Java starter", r#"public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, world!");
    }
}"#, vec![
            "Java source declares a class; this example uses `Main`.".into(),
            "`main` is the conventional application entry point.".into(),
            "`System.out.println` prints a line.".into(),
        ]),
        Language::CSharp => ("C# starter", r#"using System;

class Program {
    static void Main() {
        Console.WriteLine("Hello, world!");
    }
}"#, vec![
            "`using System` imports common .NET types.".into(),
            "`Main` is the application entry point in this example.".into(),
            "`Console.WriteLine` prints a line.".into(),
        ]),
        Language::Lua => ("Lua starter", r#"local function main()
    print("Hello, world!")
end

main()"#, vec![
            "`local function` declares a function local to this chunk.".into(),
            "`print` writes text to the standard output.".into(),
            "`main()` calls the function.".into(),
        ]),
    };
    AssistantReply {
        title: name.into(),
        message: format!("Here is a built-in {} starter template.", lang.display()),
        code: Some(code.into()),
        explanation,
        source: "bundled template library".into(),
    }
}

pub fn explain_language(lang: Language) -> AssistantReply {
    let explanation = match lang {
        Language::Cpp => vec!["C++ is a compiled, general-purpose language.".into(), "Common build tools include Clang and GCC.".into(), "This assistant's built-in C++ support currently covers templates and known-rule suggestions, not the full C++ standard.".into()],
        Language::Rust => vec!["Rust emphasizes memory safety through ownership and borrowing.".into(), "Cargo manages Rust packages, builds, and tests.".into(), "The compiler `rustc` provides authoritative type and borrow checking.".into()],
        Language::Python => vec!["Python is a high-level interpreted language.".into(), "Indentation defines code blocks.".into(), "The standard interpreter is `python` or `python3`.".into()],
        Language::JavaScript => vec!["JavaScript is widely used in browsers and server runtimes such as Node.js.".into(), "Use `const` by default and `let` when reassignment is needed.".into(), "The runtime or browser reports execution errors.".into()],
        Language::Java => vec!["Java is a statically typed, class-based language.".into(), "The JDK includes `javac` and the Java runtime.".into(), "A public class is normally stored in a file with the same name.".into()],
        Language::CSharp => vec!["C# is a statically typed language in the .NET ecosystem.".into(), "The .NET SDK provides `dotnet build` and `dotnet run`.".into(), "Types, namespaces, and project configuration affect compilation.".into()],
        Language::Lua => vec!["Lua is a lightweight embeddable scripting language.".into(), "Tables are Lua's main compound data structure.".into(), "The `lua` interpreter runs Lua source files.".into()],
    };
    AssistantReply {
        title: format!("{} quick guide", lang.display()),
        message: format!("These are predefined notes about {}.", lang.display()),
        code: None,
        explanation,
        source: "bundled knowledge base".into(),
    }
}

pub fn known_error(question: &str) -> Option<AssistantReply> {
    let q = question.to_ascii_lowercase();
    let (title, message, tips): (&str, &str, Vec<&str>) =
        if q.contains("undefined reference") || q.contains("unresolved external") {
            ("Linker error: undefined reference",
             "The linker cannot find a definition for a symbol your program uses.",
             vec!["Confirm the function or global variable has a matching definition.", "Ensure the source file containing the definition is included in the build.", "Check that declaration and definition signatures match.", "For external libraries, verify the library is installed and linked."])
        } else if q.contains("segmentation fault") || q.contains("access violation") {
            ("Invalid memory access",
             "The program attempted to access memory it was not permitted to access.",
             vec!["Check pointers before dereferencing them.", "Check array indexes and iterator validity.", "Avoid using objects after their lifetime ends.", "Use a debugger or memory sanitizer to locate the failing access."])
        } else if q.contains("cannot find") && (q.contains("module") || q.contains("crate") || q.contains("package")) {
            ("Dependency or module not found",
             "The compiler or runtime cannot resolve a referenced dependency or module.",
             vec!["Check the dependency name and spelling.", "Install or declare the dependency using the language's package manager.", "Verify the module search path and project configuration."])
        } else if q.contains("borrow") && q.contains("rust") {
            ("Rust borrowing suggestion",
             "A borrow-checker diagnostic usually means a reference would outlive its data or conflict with another borrow.",
             vec!["Read the exact compiler span first.", "Avoid keeping a reference while mutating the same value.", "Consider taking ownership, shortening the borrow's scope, or cloning only when appropriate."])
        } else {
            return None;
        };
    Some(AssistantReply {
        title: title.into(),
        message: message.into(),
        code: None,
        explanation: tips.into_iter().map(str::to_string).collect(),
        source: "predefined diagnostic rules".into(),
    })
}
