#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

#[tauri::command]
fn app_info() -> serde_json::Value {
    serde_json::json!({
        "name": "Rust++",
        "version": env!("CARGO_PKG_VERSION"),
        "mode": "deterministic-offline",
        "languages": ["C++", "Rust", "Python", "JavaScript", "Java", "C#", "Lua"]
    })
}

#[tauri::command]
fn generate_template(language: String) -> Result<rust_plus_plus::AssistantReply, String> {
    let lang = rust_plus_plus::parse_language(&language).map_err(|e| e.to_string())?;
    Ok(rust_plus_plus::knowledge::template(lang))
}

#[tauri::command]
fn explain_language(language: String) -> Result<rust_plus_plus::AssistantReply, String> {
    let lang = rust_plus_plus::parse_language(&language).map_err(|e| e.to_string())?;
    Ok(rust_plus_plus::knowledge::explain_language(lang))
}

#[tauri::command]
fn analyze_request(question: String) -> rust_plus_plus::AssistantReply {
    rust_plus_plus::engine::answer(&question)
}

#[tauri::command]
fn validate_source(language: String, source: String) -> Result<rust_plus_plus::AssistantReply, String> {
    let lang = rust_plus_plus::parse_language(&language).map_err(|e| e.to_string())?;
    Ok(rust_plus_plus::validate::lightweight_check(&source, lang))
}

#[tauri::command]
fn save_source_file(path: String, source: String) -> Result<String, String> {
    let path = std::path::PathBuf::from(path);
    if path.as_os_str().is_empty() { return Err("Choose a file path first.".into()); }
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent).map_err(|e| format!("Could not create folder: {e}"))?;
    }
    std::fs::write(&path, source).map_err(|e| format!("Could not save file: {e}"))?;
    Ok(format!("Saved {}", path.display()))
}

#[tauri::command]
fn read_source_file(path: String) -> Result<String, String> {
    std::fs::read_to_string(&path).map_err(|e| format!("Could not open file: {e}"))
}

fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![
            app_info, generate_template, explain_language, analyze_request,
            validate_source, save_source_file, read_source_file
        ])
        .run(tauri::generate_context!())
        .expect("error while running Rust++");
}
