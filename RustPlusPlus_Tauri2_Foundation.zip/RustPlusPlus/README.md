# Rust++

Rust++ is a deterministic, offline-capable coding assistant with a shared Rust engine and a Tauri 2 application shell for Windows, Android, and iOS.

## What is included

- Existing Rust engine retained as a reusable library (`src/lib.rs`).
- Tauri 2 application in `src-tauri/`.
- Responsive frontend in `src-ui/` (Vite).
- Native commands for bundled templates, language explanations, rule-based analysis, lightweight validation, and local file read/write.
- Existing CLI/Discord adapter retained behind the optional `discord` feature.

## Requirements

- Rust stable toolchain and Cargo.
- Node.js 20+ and npm.
- Tauri platform prerequisites: https://v2.tauri.app/start/prerequisites/

### Windows desktop

Install Microsoft C++ Build Tools and WebView2 (see Tauri prerequisites), then:

```bash
npm install
npm run tauri dev
```

Build an installer/bundle:

```bash
npm run tauri build
```

### Android

Install Android Studio, Android SDK, NDK, and Java (follow the official Tauri Android prerequisites). Then initialize the Android target once:

```bash
npm install
npm run tauri android init
npm run tauri android dev
```

Build Android packages:

```bash
npm run tauri android build
```

### iOS

iOS builds require macOS, Xcode, and the Apple toolchain. On a Mac:

```bash
npm install
npm run tauri ios init
npm run tauri ios dev
npm run tauri ios build
```

Signing and App Store distribution require the appropriate Apple certificates and provisioning.

## Engine tests

```bash
cargo check
cargo test
```

The Tauri native app is a separate Cargo package under `src-tauri` and is compiled by the Tauri CLI. A normal browser preview can display the interface, but native commands (file access and Rust engine calls) require the Tauri runtime.

## Design constraints

- No AI API, remote model, or generative AI dependency.
- Answers are produced by bundled templates, explicit rules, and predefined explanations.
- The current validator is lightweight structural checking, not a full parser or compiler.
- File open/save currently accepts a local path; a native file picker and project explorer are planned next.

## Project layout

```text
src/                 Shared deterministic Rust engine
src-tauri/           Tauri 2 native application
src-ui/              Responsive frontend
index.html           Vite entry point
package.json         Frontend and Tauri CLI scripts
tests/               Engine tests
```
