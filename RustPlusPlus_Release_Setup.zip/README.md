# Rust++ automated release workflow

This setup adds GitHub Actions to build Windows/macOS desktop bundles and an Android APK.

## Before the first release

1. Copy the `.github` folder into the root of your RustPlusPlus repository.
2. In your Codespace, initialize Android once:
   ```bash
   cd /workspaces/RustPlusPlus
   npm install
   npm run tauri android init
   ```
   If your Codespace uses a different project path, `cd` to the repository root instead.
3. Commit the generated `src-tauri/gen/android` project and the workflow:
   ```bash
   git add .github src-tauri/gen/android
   git commit -m "Add automated cross-platform release builds"
   git push
   ```

## Publish a release

Create and push a version tag:
```bash
git tag v0.1.0
git push origin v0.1.0
```

GitHub Actions will build Windows and macOS bundles, and build the Android APK. The APK is uploaded as a workflow artifact and attached to the GitHub Release for tagged builds.

## Important limitations

- Android signing is not configured here. The generated APK is suitable for testing/sideloading; Play Store publication requires a signed release APK/AAB and Play Console setup.
- iOS is not included in this workflow. iOS builds require a macOS runner plus Apple signing certificates/provisioning profiles and an Apple Developer account.
- Linux is not included yet. It can be added after choosing the desired package format and installing the required system libraries.
- This workflow expects the Tauri v2 Android project to have been initialized using `npm run tauri android init`.
- The workflow uses the repository's existing `package-lock.json` via `npm ci`. Make sure that file is committed.
